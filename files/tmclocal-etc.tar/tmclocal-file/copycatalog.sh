TKG_IMAGE_REGISTRY=projects.registry.vmware.com/tkg
PRIVATE_IMAGE_REGISTRY=harbor.tanzukorea.net
TMC_PROJECT=tmc-local

imgpkg copy --registry-verify-certs=false \
-b ${TKG_IMAGE_REGISTRY}/packages/standard/repo:v2.1.1 --to-repo ${PRIVATE_IMAGE_REGISTRY}/${TMC_PROJECT}/498533941640.dkr.ecr.us-west-2.amazonaws.com/packages/standard/repo --registry-username=tanzukr --registry-password=VMware1!
