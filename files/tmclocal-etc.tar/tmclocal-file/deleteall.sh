helm ls -q -n tmc-local |grep -v contour |awk '{print $1}' |xargs helm -n tmc-local delete

kubectl get secret -n tmc-local |awk '{print $1}' |xargs kubectl delete secret -n tmc-local
kubectl get certificate -n tmc-local |awk '{print $1}' |xargs kubectl delete certificate -n tmc-local
kubectl get deployments -n tmc-local |grep -v contour |awk '{print $1}' |xargs kubectl delete deployment -n tmc-local
kubectl get httpproxy -n tmc-local |awk '{print $1}'|xargs kubectl delete httpproxy -n tmc-local
kubectl get configmap -n tmc-local  |awk '{print $1}'|xargs kubectl delete configmap -n tmc-local
