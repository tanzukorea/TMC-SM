kubectl  get issuer,clusterissuer,pvc,pv,configmap,svc,httpproxy,secret,certificate,pods,challenge -n tmc-local
