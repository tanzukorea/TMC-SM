./tmc-local deploy --values ./values.yaml --kubeconfig ../.kube/config --namespace tmc-local --image-prefix harbor.tanzukorea.net/tmc-local --debug
