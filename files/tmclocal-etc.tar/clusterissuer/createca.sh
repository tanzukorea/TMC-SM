openssl req -x509 -newkey rsa:4096 -sha256 -days 365 -nodes \
-keyout ca.tanzukorea.net.key -out ca.tanzukorea.net.cer \
-subj /C=KR/ST=MH/L=PUN/O=TanzuKr/OU=Tanzu/CN=*.tanzukorea.net \
-extensions ext \
-config <(cat <<EOF
[req]
distinguished_name=req
[ext]
keyUsage=critical,keyCertSign,cRLSign
basicConstraints=critical,CA:true,pathlen:1
subjectAltName=DNS:*.tanzukorea.net
EOF
)
