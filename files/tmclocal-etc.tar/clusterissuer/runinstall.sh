kubectl create secret tls root-secret --cert fullchain.pem --key privkey.pem -n cert-manager
kubectl create secret tls root-secret --cert fullchain.pem --key privkey.pem -n keycloak
kubectl create secret docker-registry harbor-credentials --docker-server=https://harbor.tanzukorea.net --docker-username=tanzukr --docker-password="VMware1!" -n tmc-local
kubectl apply -f clusterissuer_rootca.yaml
